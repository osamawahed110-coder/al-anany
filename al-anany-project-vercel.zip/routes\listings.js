const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const db = require('../database/db');

const fs = require('fs');
const os = require('os');

const getUploadDir = () => {
  const isVercel = process.env.VERCEL || process.env.NOW_BUILD;
  const uploadDir = isVercel ? path.join(os.tmpdir(), 'uploads') : path.join(__dirname, '../uploads');
  if (!fs.existsSync(uploadDir)) {
    try { fs.mkdirSync(uploadDir, { recursive: true }); } catch (e) {}
  }
  return uploadDir;
};

// Multer storage for listing inquiries
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, getUploadDir());
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, 'listing-' + unique + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  const allowed = /jpeg|jpg|png|gif|webp|mp4|mov|avi|mkv|webm/;
  const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
  cb(null, allowed.test(ext));
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});

// POST /api/listings — submit a new listing request from public
router.post('/', upload.array('files', 10), (req, res) => {
  const { name, phone, listing_type, description } = req.body;

  if (!name || !phone) {
    return res.status(400).json({ success: false, message: 'الاسم ورقم الهاتف مطلوبان' });
  }

  const files = (req.files || []).map(f => f.filename);

  const record = db.insert('listing_requests', {
    name,
    phone,
    listing_type: listing_type || 'بيع',
    description: description || '',
    files: JSON.stringify(files),
    status: 'new'
  });

  res.status(201).json({
    success: true,
    message: 'تم إرسال طلبك بنجاح! سيتواصل معك فريقنا قريباً',
    data: { id: record.id }
  });
});

// GET /api/listings — for admin dashboard (protected)
router.get('/', require('../middleware/auth'), (req, res) => {
  const requests = db.find('listing_requests');
  requests.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ success: true, data: requests });
});

// DELETE /api/listings/:id — protected
router.delete('/:id', require('../middleware/auth'), (req, res) => {
  const id = parseInt(req.params.id);
  db.delete('listing_requests', r => r.id === id);
  res.json({ success: true, message: 'تم حذف الطلب' });
});

module.exports = router;
