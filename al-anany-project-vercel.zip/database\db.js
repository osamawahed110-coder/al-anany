/**
 * JSON-based database — no native modules required
 * Data is stored in database/data.json (auto-created)
 */

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const os = require('os');
const isVercel = process.env.VERCEL || process.env.NOW_BUILD;

const LOCAL_DATA_FILE = path.join(__dirname, 'data.json');
const TMP_DATA_FILE = path.join(os.tmpdir(), 'al_anani_data.json');

function getDataFilePath() {
  if (isVercel) {
    if (!fs.existsSync(TMP_DATA_FILE) && fs.existsSync(LOCAL_DATA_FILE)) {
      try {
        fs.copyFileSync(LOCAL_DATA_FILE, TMP_DATA_FILE);
      } catch (e) {
        console.error('Failed to copy initial DB file to tmp:', e);
      }
    }
    return TMP_DATA_FILE;
  }
  return LOCAL_DATA_FILE;
}

// ===== DEFAULT DATA STRUCTURE =====
const DEFAULT_DATA = {
  users: [],
  properties: [],
  media: [],
  site_content: {},
  listing_requests: [],
  _counters: { users: 0, properties: 0, media: 0, listing_requests: 0 }
};

// ===== READ / WRITE =====
function readDB() {
  const filePath = getDataFilePath();
  try {
    if (!fs.existsSync(filePath)) {
      writeDB(DEFAULT_DATA);
      return JSON.parse(JSON.stringify(DEFAULT_DATA));
    }
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (e) {
    console.error('DB read error:', e);
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
}

function writeDB(data) {
  const filePath = getDataFilePath();
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    console.error('DB write error:', e);
  }
}

// ===== QUERY HELPERS =====
const db = {
  // Generic find
  find(table, predicate) {
    const data = readDB();
    const rows = data[table] || [];
    return predicate ? rows.filter(predicate) : rows;
  },
  findOne(table, predicate) {
    return this.find(table, predicate)[0] || null;
  },

  // Insert
  insert(table, record) {
    const data = readDB();
    if (!data[table]) data[table] = [];
    if (!data._counters) data._counters = {};
    data._counters[table] = (data._counters[table] || 0) + 1;
    const newRecord = { id: data._counters[table], created_at: new Date().toISOString(), ...record };
    data[table].push(newRecord);
    writeDB(data);
    return newRecord;
  },

  // Update
  update(table, id, updates) {
    const data = readDB();
    const idx = (data[table] || []).findIndex(r => r.id === id);
    if (idx === -1) return null;
    data[table][idx] = { ...data[table][idx], ...updates, updated_at: new Date().toISOString() };
    writeDB(data);
    return data[table][idx];
  },

  // Delete
  delete(table, predicate) {
    const data = readDB();
    const before = (data[table] || []).length;
    data[table] = (data[table] || []).filter(r => !predicate(r));
    writeDB(data);
    return before - data[table].length;
  },

  // Content (key-value)
  getContent() {
    return readDB().site_content || {};
  },
  setContent(updates) {
    const data = readDB();
    data.site_content = { ...data.site_content, ...updates };
    writeDB(data);
  }
};

// ===== SEED DATA =====
function seedData() {
  const data = readDB();

  // Seed admin user
  if (!data.users || data.users.length === 0) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.insert('users', { username: 'admin', password_hash: hash, role: 'admin' });
    console.log('✅ Default admin created: admin / admin123');
  }

  // Seed site content
  const defaults = {
    hero_title: 'العناني للتسويق العقاري',
    hero_subtitle: 'نجد لك البيت الذي تحلم به بأفضل الأسعار وأعلى المعايير',
    hero_cta: 'اكتشف العقارات',
    about_title: 'من نحن',
    about_text: 'تأسست شركة العناني للتسويق العقاري سنة 2000، وهي شركة رائدة في مجال الخدمات والتسويق العقاري، نقدم أفضل الفرص الاستثمارية والسكنية بخبرة متميزة في السوق العقاري.',
    contact_phone: '01000000000',
    contact_email: 'info@alanani.com',
    contact_address: 'القاهرة، مصر',
    footer_text: 'جميع الحقوق محفوظة © 2026 العناني للتسويق العقاري',
    stats_projects: '500+',
    stats_clients: '1200+',
    stats_years: '26+'
  };
  const existing = db.getContent();
  const merged = { ...defaults, ...existing };
  db.setContent(merged);

  // Seed sample properties
  const freshData = readDB();
  if (!freshData.properties || freshData.properties.length === 0) {
    db.insert('properties', { title: 'شقة فاخرة بالتجمع الخامس', description: 'شقة راقية بتشطيبات سوبر لوكس، 3 غرف نوم، صالة واسعة', price: '3,500,000', price_num: 3500000, type: 'sale', location: 'التجمع الخامس', area: '180 م²', bedrooms: 3, bathrooms: 2, status: 'available', featured: true });
    db.insert('properties', { title: 'فيلا مودرن بمدينتي', description: 'فيلا مستقلة بحديقة خاصة وحمام سباحة، تشطيبات فاخرة', price: '12,000,000', price_num: 12000000, type: 'sale', location: 'مدينتي', area: '450 م²', bedrooms: 5, bathrooms: 4, status: 'available', featured: true });
    db.insert('properties', { title: 'محل تجاري بالعاصمة الإدارية', description: 'محل تجاري في موقع استراتيجي في مول تجاري شهير', price: '2,200,000', price_num: 2200000, type: 'commercial', location: 'العاصمة الإدارية', area: '85 م²', bedrooms: 0, bathrooms: 1, status: 'available', featured: true });
    db.insert('properties', { title: 'شقة للإيجار بمدينة الشروق', description: 'شقة للإيجار في أرقى أحياء الشروق مفروشة بالكامل', price: '9,500', price_num: 9500, type: 'rent', location: 'مدينة الشروق', area: '140 م²', bedrooms: 3, bathrooms: 2, status: 'available', featured: true });
    db.insert('properties', { title: 'شقة للبيع بمدينة بدر', description: 'شقة ممتازة قريبة من الخدمات والجامعات', price: '1,350,000', price_num: 1350000, type: 'sale', location: 'بدر', area: '110 م²', bedrooms: 2, bathrooms: 1, status: 'available', featured: false });
    console.log('✅ Sample properties created');
  }
}

seedData();

module.exports = db;
